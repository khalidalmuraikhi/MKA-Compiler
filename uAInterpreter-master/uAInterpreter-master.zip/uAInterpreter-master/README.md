# μAInterpreter
An implementation of the μA language and a few sample programs
